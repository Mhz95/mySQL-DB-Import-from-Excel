/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 *
 * @author malsulmi
 */
public class Test {

    public static void main(String[] args) {

        try {
            String stockCode = "2010";

            // use jsoup + SSLHelper to connect and obain the document from a link
            Document doc = SSLHelper.getConnection("https://www.tadawul.com.sa/wps/portal/tadawul/markets/Press-Release/news-%26-announcements/!ut/p/z1/pZDLjoJAEEW_xQXrvjag6I4BBAYkgww-emNajUjCKxPU6NfbPjYmimOsXSXn3EpdwsiUsILv0oTXaVnwTOwz1pkHjm840KhnW78y9I45NEaBSwGQyQWg1NDaPQU-_G5bADbccKjICGXC3vJtN-hCD3VnPBgLVKOf-VD-5-PJ6HjlfxOWZOXiWtWmrqu-BAk1X_H9NpOEvizziheH6JAvSgFRyOej7D4XDjVFruV5pqFSfKk3oKnXe-BBcY3AuZkL0PB6xP9IlcdxPD3668hNf5JW6wSWl2M9/dz/d5/L0lJSklLVUtVSklBIS9JTGpBQUF4QUFFUWtLa3JvQUdZIS80TmxHUW9ZaE9MZ1N1M01RL1o2X05ITENIMDgySzBURTAwQU1PSkZSNUoxOEwwL1o3X0lQRzQxSTgySzhOSzMwQUUxSzA0SE0xMDQ0L25vcm1hbC92aWV3/?annoucmentType=1_-1&searchType=1&symbol=" + stockCode).userAgent("Chrome").get();

            String title = doc.title();
            
            System.out.println(title);
            
            // we want to obtain total number of pages containing announcements, look at the document source
            int numPages = 0;

            // num pages is in one of <span class=..> tags, so select it
            Elements links = doc.select("span[class]");     // this will give all the tags with <span class=..>

            // iterate all the tags with <span class=..> and only extract the one with number of pages
            for (Element link : links) {
                if (link.attr("abs:class").contains("dot")) {
                    numPages = Integer.parseInt(link.text().split("\\s+")[2]);      //parse the string "1 of xx"
                }
            }

            // iterate over all pages, then extract the link to each announcement, access the announcement page and you should take it from there
            for (int i = 1; i <= numPages; i++) {
                System.out.println("Page No : " + i + " out of " + numPages);
                doc = SSLHelper.getConnection("https://www.tadawul.com.sa/wps/portal/tadawul/markets/Press-Release/news-%26-announcements/!ut/p/z1/pZJLc4IwFIV_iwuXndyEgLQ7BORNq-ADNk60VOnIYxR19Nc3oAttq3amd5ebc-658yUoRhMU52yXLliVFjlb8XMUS1PfdFUTZOJAqAMo3qvdG4g2ll1A40ZAiCrjZwouuB0MimSA1feoAH0BxZd-Qw8Ffq156sC3CMAPv2H5HVD6ijnqjbhUJv_zA73239ofbpQCf_PfyjeER34bxYtVMTuhXlZV-dKGNlTsne23qzaPnxdZyfJDcMhmBRcREOrQ-Ntck2ici-44mioS6Ipnwb13uRb8Av6uoCbbCO6hawTWm0GxxZeUQ6kLylB1fc0PMIjSgwgOL2BrFHHCnYspvsO_gI4doKaHgVI0zIt1xgGOd2myR0E9dZOw9XwZHsoERbhusDwvtvMsyatzc_rU9DcnrFGDtcyGvCZH9yOwUuuTRvbOFxet1hd2ITRB/p0/IZ7_IPG41I82K8NK30AE1K04HM1044=CZ6_NHLCH082K0TE00AMOJFR5J18L0=M/?searchType=1&datePeriod=-1&textSearch=&pageNo=" + i + "&annoucmentType=1_-1&productType=E&sectorId=-1&symbol=" + stockCode).userAgent("Chrome").get();

                // extract all links in this page
                links = doc.select("a[href]");

                for (Element link : links) {

                    // this will filter only links to announcements
                    if (link.attr("abs:href").contains("/wps/portal/tadawul/home/announcement-details")) {
                        String announLink = link.attr("abs:href");
                        System.out.println(announLink);

                        
                        // take it from here
                    }
                }
            }

        } catch (IOException ex) {
            Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
